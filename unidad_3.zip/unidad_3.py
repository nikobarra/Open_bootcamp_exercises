def sumar(num_1,num_2,num_3):
    return num_1+num_2+num_3


print (sumar (4,5,2))


